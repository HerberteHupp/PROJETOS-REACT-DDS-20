import { Link } from "react-router-dom"

const PaginaErro = () => {
  return (
    <div>
      <h1>PaginaErro</h1>
      <Link to="/login">Clique aqui para ir para login</Link>
    </div>
  )
}

export default PaginaErro