import React from 'react'

const Cadastro = () => {
  return (
    <div>Cadastro</div>
  )
}

export default Cadastro