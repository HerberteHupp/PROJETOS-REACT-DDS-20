import { Link } from "react-router-dom";

const Sobre = () => {
  return (
    <div>
      <h1>Sobre</h1>
    </div>
  );
};

export default Sobre;
